package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.List;

import co.edu.unbosque.model.CitaDTO;
import co.edu.unbosque.model.CitaDisponibleDTO;
import co.edu.unbosque.model.Clinica;
import co.edu.unbosque.model.PersonaDTO;
import co.edu.unbosque.model.TurnoDTO;
import co.edu.unbosque.model.exception.CredencialesInvalidasException;
import co.edu.unbosque.view.VentanaPrincipal;
import java.util.UUID;

/**
 * Clase Controller que maneja la lógica de la aplicación.
 */
public class Controller implements ActionListener {
	VentanaPrincipal ventana;
	Clinica clinica;
	PersonaDTO personaDTO;

	/**
	 * Constructor de la clase Controller.
	 */
	public Controller() {
		this.clinica = new Clinica();
		this.ventana = new VentanaPrincipal(this);
		this.clinica.cargarDatos();
	}

	/**
	 * Maneja los eventos de acción.
	 * 
	 * @param event el evento de acción.
	 */
	@Override
	public void actionPerformed(ActionEvent event) {
		String actionCommand = event.getActionCommand();
		switch (actionCommand) {
			case "LOGIN":
				String correo = this.ventana.getPanelLogin().getEmail();
				String contrasena = this.ventana.getPanelLogin().getPassword();
				PersonaDTO personaDTO;
				try {
					personaDTO = this.clinica.validarCredeniales(correo, contrasena);
					if(!personaDTO.getTipoCuenta().equals(this.ventana.getPanelLogin().getAccountType())) {
						this.ventana.showError("Credenciales invalidas");
						return;
					}	

					this.personaDTO = personaDTO;

					switch(this.ventana.getPanelLogin().getAccountType()) {
						case "Paciente":
							this.mostrarPanelPacientePrincipal();
							break;
						case "Especialista":
							this.mostrarPanelEspecialistaPrincipal();
							break;
						case "Director Medico":
							this.mostrarPanelDirectorMedico();
							break;
						default:
							break;
					}

				} catch (CredencialesInvalidasException e) {
					this.ventana.showError("Credenciales invalidas");
				}
				break;

			case "CANCELAR_CITA":
				int filaSelecionada = this.ventana.getPanelPacientePrincipal().getProximasCitasTable().getSelectedRow();
				if (filaSelecionada == -1) {
					this.ventana.showMessage("Seleccione una cita.");
					return;
				}

				String citaId = (String) this.ventana.getPanelPacientePrincipal().getProximasCitasTable().getModel().getValueAt(filaSelecionada, 3);
				this.clinica.cancelarCita(citaId);
				this.mostrarPanelPacientePrincipal();
				this.ventana.showMessage("Cita cancelada.");
				break;
			
			case "MOSTRAR_AGENDAR_CITA":
				this.mostrarPanelPacienteAgendarCita();
			break;

			case "MOSTRAR_PRINCIPAL_PACIENTE":
				this.mostrarPanelPacientePrincipal();

			case "MOSTRAR_DIRECTOR_MEDICO":
				this.mostrarPanelDirectorMedico();
			break;

			case "AGREGAR_TURNO":
				LocalDate fecha = this.ventana.getPanelDirectorMedico().getFechaDatePicker().getDate();
				int especialistaItemIndex = this.ventana.getPanelDirectorMedico().getEspecialistaComboBox().getSelectedIndex();

				if (fecha == null) {
					this.ventana.showError("Seleccione una fecha.");
					return;
				}

				if (especialistaItemIndex == -1) {
					this.ventana.showError("Seleccione un especialista.");
					return;
				}

				TurnoDTO turnoDto = new TurnoDTO();
				turnoDto.setId(UUID.randomUUID().toString());
				turnoDto.setFecha(fecha);
				turnoDto.setEspecialista(this.clinica.getEspecialistas().get(especialistaItemIndex));
				turnoDto.setArea(this.clinica.getEspecialistas().get(especialistaItemIndex).getArea());
				try {
					this.clinica.agregarTurno(turnoDto);
					this.ventana.showMessage("Turno agregado.");
					this.mostrarPanelDirectorMedico();
				} catch (Exception e) {
					this.ventana.showError(e.getMessage());
				}
				break;
			case "AGENDAR_CITA":
				int filaSeleccionada = this.ventana.getPanelPacienteAgendarCita().getCitaDisponibleTable().getSelectedRow();
				if (filaSeleccionada == -1) {
					this.ventana.showMessage("Seleccione una cita.");
					return;
				}
				CitaDisponibleDTO citaDisponible = this.ventana.getPanelPacienteAgendarCita().getCitaDisponible().get(filaSeleccionada);
				String especialistaId = citaDisponible.getEspecialista().getId();

				CitaDTO citaDto = new CitaDTO();
				citaDto.setId(UUID.randomUUID().toString());
				citaDto.setFechaHora(citaDisponible.getHora());
				citaDto.setEspecialista(citaDisponible.getEspecialista());
				citaDto.setArea(citaDisponible.getEspecialista().getArea());
				citaDto.setPaciente(this.personaDTO);
				try {
					this.clinica.agregarCitaTurno(citaDto, citaDisponible.getTurnoId());
					this.ventana.showMessage("Cita agendada.");
					this.mostrarPanelPacientePrincipal();
				} catch (Exception e) {
					this.ventana.showError(e.getMessage());
				}
			break;
			


			default:
				break;
		}

	}

	/**
	 * Muestra el panel principal del paciente.
	 */
	void mostrarPanelPacientePrincipal() {
		List<CitaDTO> citasPaciente = this.clinica.getCitasPacienteDTO(this.personaDTO.getId());
		List<CitaDTO> proximasCitasTableCitas = citasPaciente;
		this.ventana.mostrarPanelPacientePrincipal(proximasCitasTableCitas);
	}

	/**
	 * Muestra el panel del director médico.
	 */
	void mostrarPanelDirectorMedico() {
		this.ventana.mostrarPanelDirectorMedico(this.clinica.getEspecialistas(), this.clinica.getTurnos());
	}

	/**
	 * Muestra el panel principal del especialista.
	 */
	void mostrarPanelEspecialistaPrincipal() {
		this.ventana.mostrarPanelEspecialistaPrincipal();
		this.ventana.getPanelEspecialistaPrincipal().actualizarCitasTable(this.clinica.getCitasEspecialistaDto(this.personaDTO.getId()));
	}

	/**
	 * Muestra el panel para agendar una cita.
	 */
	void mostrarPanelPacienteAgendarCita() {
		this.ventana.mostrarPanelPacienteAgendarCita(this.clinica.getCitasDisponibles());
		this.ventana.getPanelPacienteAgendarCita().setCitaDisponible(this.clinica.getCitasDisponibles());
	}
}
