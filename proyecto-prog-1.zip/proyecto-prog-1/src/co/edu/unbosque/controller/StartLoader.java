package co.edu.unbosque.controller;

import java.util.List;

import co.edu.unbosque.model.Clinica;
import co.edu.unbosque.model.Persona;
import co.edu.unbosque.model.persistence.PersonaDaoImpl;

public class StartLoader {
    public static void main(String[] args) {
		Clinica clinica = new Clinica();
		PersonaDaoImpl personaDao = new PersonaDaoImpl();
		List<Persona> personas = personaDao.loadPersonasFromTextFile("personas.txt");
		clinica.setPersonas(personas);
		clinica.savePersonas();
	}
}