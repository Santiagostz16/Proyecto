package co.edu.unbosque.model;

/**
 * Representa las áreas médicas para las citas.
 */
public enum Area {
    Cirugia, 
    Oncologia, 
    Dermatologia, 
    Neumologia, 
    Cardiologia, 
    MedicinaInterna
}
