package co.edu.unbosque.model;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Representa una cita médica.
 */
public class Cita implements Serializable {
    private static final long serialVersionUID = 1L;
    String id;
    Paciente paciente;
    Especialista especialista;
    LocalDateTime fechaHora;
    Area area;
    boolean esCancelada;

    /**
     * Obtiene el estado de cancelación de la cita.
     * @return true si la cita está cancelada, false en caso contrario.
     */
    public boolean getEsCancelada() {
        return esCancelada;
    }

    /**
     * Establece el estado de cancelación de la cita.
     * @param esCancelada true para cancelar la cita, false en caso contrario.
     */
    public void setEsCancelada(boolean esCancelada) {
        this.esCancelada = esCancelada;
    }

    /**
     * Obtiene el especialista de la cita.
     * @return el especialista.
     */
    public Especialista getEspecialista() {
        return especialista;
    }

    /**
     * Establece el especialista de la cita.
     * @param especialista el especialista.
     */
    public void setEspecialista(Especialista especialista) {
        this.especialista = especialista;
    }
    
    /**
     * Obtiene la fecha y hora de la cita.
     * @return la fecha y hora.
     */
    public LocalDateTime getFechaHora() {
        return fechaHora;
    }
    
    /**
     * Establece la fecha y hora de la cita.
     * @param fechaHora la fecha y hora.
     */
    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }
    
    /**
     * Obtiene el paciente de la cita.
     * @return el paciente.
     */
    public Paciente getPaciente() {
        return paciente;
    }
    
    /**
     * Establece el paciente de la cita.
     * @param paciente el paciente.
     */
    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    /**
     * Obtiene el ID de la cita.
     * @return el ID.
     */
    public String getId() {
        return id;
    }

    /**
     * Establece el ID de la cita.
     * @param id el ID.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Obtiene el área de la cita.
     * @return el área.
     */
    public Area getArea() {
        return area;
    }

    /**
     * Establece el área de la cita.
     * @param area el área.
     */
    public void setArea(Area area) {
        this.area = area;
    }

    /**
     * Devuelve una representación en cadena de la cita.
     * @return una representación en cadena.
     */
    public String toString() {
        return "Cita{" +
                "id='" + id + '\'' +
                ", paciente=" + paciente +
                ", especialista=" + especialista +
                ", fechaHora=" + fechaHora +
                ", area=" + area +
                ", esCancelada=" + esCancelada +
                '}';
    }

    /**
     * Genera el texto del correo electrónico para la cita.
     * @return el texto del correo electrónico.
     */
    public String textoEmail() {
        return """
                Cita:
                Paciente: %s
                Especialista: %s
                Fecha: %s
                Area: %s
                """.formatted(paciente.getNombre(), especialista.getNombre(), fechaHora, area);
    }
}
