package co.edu.unbosque.model;

import java.time.LocalDateTime;

public class CitaDTO {
    String id;
    PersonaDTO paciente;
    PersonaDTO especialista;
    LocalDateTime fechaHora;
    String area;

    public PersonaDTO getEspecialista() {
        return especialista;
    }

    public void setEspecialista(PersonaDTO especialista) {
        this.especialista = especialista;
    }
    
    public LocalDateTime getFechaHora() {
        return fechaHora;
    }
    
    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }
    
    public PersonaDTO getPaciente() {
        return paciente;
    }
    
    public void setPaciente(PersonaDTO paciente) {
        this.paciente = paciente;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}
