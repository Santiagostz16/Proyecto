package co.edu.unbosque.model;

import java.time.LocalDateTime;

public class CitaDisponible {
    Especialista especialista;
    LocalDateTime hora;
    Turno turno;

    public CitaDisponible() {}

    public CitaDisponible(Especialista especialista, LocalDateTime hora, Turno turno) {
        this.especialista = especialista;
        this.hora = hora;
        this.turno = turno;
    }

    public Especialista getEspecialista() {
        return especialista;
    }
    public void setEspecialista(Especialista especialista) {
        this.especialista = especialista;
    }
    public LocalDateTime getHora() {
        return hora;
    }
    public void setHora(LocalDateTime hora) {
        this.hora = hora;
    }
    public Turno getTurno() {
        return turno;
    }
    public void setTurno(Turno turno) {
        this.turno = turno;
    }
}
