package co.edu.unbosque.model;

import java.time.LocalDateTime;

public class CitaDisponibleDTO {
    PersonaDTO especialista;
    LocalDateTime hora;
    String turnoId;

    public CitaDisponibleDTO() {}

    public CitaDisponibleDTO(PersonaDTO especialista, LocalDateTime hora, String turnoId) {
        this.especialista = especialista;
        this.hora = hora;
        this.turnoId = turnoId;
    }

    public LocalDateTime getHora() {
        return hora;
    }
    public void setHora(LocalDateTime hora) {
        this.hora = hora;
    }
    
    public PersonaDTO getEspecialista() {
        return especialista;
    }

    public void setEspecialista(PersonaDTO especialista) {
        this.especialista = especialista;
    }

    public String getTurnoId() {
        return turnoId;
    }

    public void setTurnoId(String turnoId) {
        this.turnoId = turnoId;
    }
}
