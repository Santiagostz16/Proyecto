package co.edu.unbosque.model;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import co.edu.unbosque.model.exception.*;
import co.edu.unbosque.model.persistence.PersonaDao;
import co.edu.unbosque.model.persistence.PersonaDaoImpl;
import co.edu.unbosque.model.persistence.PropiedadesDao;
import co.edu.unbosque.model.persistence.PropiedadesDaoImpl;
import co.edu.unbosque.model.persistence.TurnoDao;
import co.edu.unbosque.model.persistence.TurnoDaoImpl;

/**
 * Clase Clinica que maneja la lógica de la clínica.
 */
public class Clinica {
    List<Persona> personas;
    List<Turno> turnos;
    PersonaDao personaDao;
    TurnoDao turnoDao;
    PropiedadesDao propiedadesDao;
    Notificador notificador;

    /**
     * Constructor de la clase Clinica.
     */
    public Clinica() {
        this.personas = new ArrayList<>();
        this.turnos = new ArrayList<>();
        this.personaDao = new PersonaDaoImpl();
        this.turnoDao = new TurnoDaoImpl();
        this.propiedadesDao = new PropiedadesDaoImpl();
    }

    /**
     * Valida las credenciales de un usuario.
     * 
     * @param correo el correo del usuario.
     * @param contrasena la contraseña del usuario.
     * @return el objeto PersonaDTO del usuario.
     * @throws CredencialesInvalidasException si las credenciales son inválidas.
     */
    public PersonaDTO validarCredeniales(String correo, String contrasena) throws CredencialesInvalidasException {
        for (Persona persona : personas) {
            if (persona.getCorreo().equals(correo) && persona.getCorreo().equals(contrasena)) {
                PersonaDTO personaDto = DataMapper.toPersonaDTO(persona);
                return personaDto;
            }
        }
        throw new CredencialesInvalidasException("Credenciales invalidas");
    }

    /**
     * Agrega una persona a la lista de personas.
     * 
     * @param personaDto el objeto PersonaDTO de la persona a agregar.
     */
    public void agregarPersona(PersonaDTO personaDto) {
        Persona persona = DataMapper.toPersona(personaDto);
        personas.add(persona);
    }    

    public List<Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(List<Persona> personas) {
        this.personas = personas;
    }

    /**
     * Obtiene la lista de citas.
     * 
     * @return la lista de citas.
     */
    private List<Cita> getCitas() {
        ArrayList<Cita> citas = new ArrayList<>();
        for (Turno turno : turnos) {
            citas.addAll(turno.getCitas().stream().filter(cita -> !cita.getEsCancelada()).toList());
        }
        citas.sort((cita1, cita2) -> cita1.getFechaHora().compareTo(cita2.getFechaHora()));
        return citas;
    }

    /**
     * Obtiene la lista de citas disponibles.
     * 
     * @return la lista de citas disponibles.
     */
    public List<CitaDisponibleDTO> getCitasDisponibles() {
        List<CitaDisponibleDTO> citasDisponiblesDto = new ArrayList<>();
        List<CitaDisponible> citasDisponibles = new ArrayList<>();

        for (Turno turno : turnos) {
            citasDisponibles.addAll(turno.obtenerHorariosDisponibles());
        }
        citasDisponibles.sort((cita1, cita2) -> cita1.getHora().compareTo(cita2.getHora()));
        for (CitaDisponible citaDisponible : citasDisponibles) {
            citasDisponiblesDto.add(DataMapper.toCitaDisponibleDTO(citaDisponible));
        }
        return citasDisponiblesDto;
    }

    /**
     * Obtiene la lista de citas de un paciente.
     * 
     * @param idPaciente el ID del paciente.
     * @return la lista de citas del paciente.
     */
    private List<Cita> getCitasPaciente(String idPaciente) {
        ArrayList<Cita> citas = new ArrayList<>();
        for (Cita cita : getCitas()) {
            if (cita.getPaciente().getId().equals(idPaciente)) {
                citas.add(cita);
            }
        }
        return citas;
    }

    /**
     * Obtiene la lista de citas de un especialista.
     * 
     * @param idEspecialista el ID del especialista.
     * @return la lista de citas del especialista.
     */
    private List<Cita> getCitasEspecialista(String idEspecialista) {
        ArrayList<Cita> citas = new ArrayList<>();
        for (Cita cita : getCitas()) {
            if (cita.getEspecialista().getId().equals(idEspecialista)) {
                citas.add(cita);
            }
        }
        return citas;
    }

    /**
     * Obtiene la lista de citas de un paciente en formato DTO.
     * 
     * @param idPaciente el ID del paciente.
     * @return la lista de citas del paciente en formato DTO.
     */
    public List<CitaDTO> getCitasPacienteDTO(String idPaciente) {
        List<Cita> citas = getCitasPaciente(idPaciente);
        List<CitaDTO> citasDto = new ArrayList<>();
        for (Cita cita : citas) {
            citasDto.add(DataMapper.toCitaDTO(cita));
        }
        return citasDto;
    }

    /**
     * Obtiene la lista de citas de un especialista en formato DTO.
     * 
     * @param idEspecialita el ID del especialista.
     * @return la lista de citas del especialista en formato DTO.
     */
    public List<CitaDTO> getCitasEspecialistaDto(String idEspecialita) {
        List<Cita> citas = getCitasEspecialista(idEspecialita);
        List<CitaDTO> citasDto = new ArrayList<>();
        for (Cita cita : citas) {
            citasDto.add(DataMapper.toCitaDTO(cita));
        }
        return citasDto;
    }

    /**
     * Obtiene un turno por su ID.
     * 
     * @param idTurno el ID del turno.
     * @return el objeto Turno.
     */
    private Turno getTurno(String idTurno) {
        for (Turno turno : turnos) {
            if (turno.getId().equals(idTurno)) {
                return turno;
            }
        }
        return null;
    }

    /**
     * Agrega una cita a un turno.
     * 
     * @param citaDto el objeto CitaDTO de la cita a agregar.
     * @param idTurno el ID del turno.
     */
    public void agregarCitaTurno(CitaDTO citaDto, String idTurno) {
        Turno turno = getTurno(idTurno);
        Cita cita = DataMapper.toCita(citaDto);
        turno.agregarCita(cita);
        this.saveTurnos();
        if (notificador != null) {
            notificador.enviarCorreo(cita.getPaciente().getCorreo(), "Cita cancelada", 
            """
                Cita asignada
            """ + cita.textoEmail());

            notificador.enviarCorreo(cita.getEspecialista().getCorreo(), "Cita cancelada", 
            """
                Nueva cita asignada
            """ + cita.textoEmail());
        }
    }

    /**
     * Cancela una cita.
     * 
     * @param idCita el ID de la cita a cancelar.
     */
    public void cancelarCita(String idCita) {
        for (Turno turno : turnos) {
            for (Cita cita : turno.getCitas()) {
                if (cita.getId().equals(idCita)) {
                    cita.setEsCancelada(true);
                    this.saveTurnos();
                    if (notificador != null) {
                        notificador.enviarCorreo(cita.getPaciente().getCorreo(), "Cita cancelada", 
                        """
                            Su cita fue cancelada
                        """ + cita.textoEmail());

                        notificador.enviarCorreo(cita.getEspecialista().getCorreo(), "Cita cancelada", 
                        """
                            El paciente cancelo la cita
                        """ + cita.textoEmail());
                    }

                }
            }
        }
    }

    /**
     * Agrega un turno.
     * 
     * @param turnoDto el objeto TurnoDTO del turno a agregar.
     * @throws TurnoYaExistenteException si ya existe un turno con el mismo especialista en la misma fecha.
     * @throws TurnoConsecutivoException si el especialista tiene un turno el día anterior o el día siguiente.
     * @throws TurnosSemanalesExcedidosException si el especialista ya tiene al menos 2 turnos asignados en la semana.
     */
    public void agregarTurno(TurnoDTO turnoDto) throws TurnoYaExistenteException, TurnoConsecutivoException, TurnosSemanalesExcedidosException {
        Turno turno = DataMapper.toTurno(turnoDto);
        for (Turno existingTurno : turnos) {
            if (existingTurno.getFecha().equals(turno.getFecha()) && 
                existingTurno.getEspecialista().getId().equals(turno.getEspecialista().getId())) {
                throw new TurnoYaExistenteException("Ya existe un turno con el mismo especialista en la misma fecha");
            }
        }

        for (Turno existingTurno : turnos) {
            if (existingTurno.getEspecialista().getId().equals(turno.getEspecialista().getId())) {
            LocalDate fechaTurno = turno.getFecha();
            LocalDate fechaExistente = existingTurno.getFecha();
                if (fechaExistente.equals(fechaTurno.minusDays(1)) || fechaExistente.equals(fechaTurno.plusDays(1))) {
                    throw new TurnoConsecutivoException("El especialista tiene un turno el día anterior o el día siguiente");
                }
            }
        }

        int turnosEnLaSemana = 0;
        for (Turno existingTurno : turnos) {
            if (existingTurno.getEspecialista().getId().equals(turno.getEspecialista().getId())) {
            LocalDate fechaTurno = turno.getFecha();
            LocalDate fechaExistente = existingTurno.getFecha();
                if (fechaExistente.isAfter(fechaTurno.minusDays(3)) && fechaExistente.isBefore(fechaTurno.plusDays(3))) {
                    turnosEnLaSemana++;
                }
            }
        }

        if (turnosEnLaSemana >= 2) {
            throw new TurnosSemanalesExcedidosException("El especialista ya tiene al menos 2 turnos asignados en la semana");
        }

        turnos.add(turno);
        this.saveTurnos();
        if (notificador != null) {
            notificador.enviarCorreo(turno.getEspecialista().getCorreo(), "Turno asignado", 
            """
                Se ha asignado un turno
            """ + turno.textoEmail());
        }
    }

    /**
     * Carga el notificador.
     */
    public void loadNotificador() {
        if (notificador == null) {
            String fromEmail = propiedadesDao.load().getProperty("EMAIL_HOST_USER");
            String password = propiedadesDao.load().getProperty("EMAIL_HOST_PASSWORD");
            notificador = new Notificador(fromEmail, password);
        }
    }

    /**
     * Carga los datos de personas y turnos.
     */
    public void cargarDatos() {
        try {
            personas = this.personaDao.loadPersonas();
            turnos = this.turnoDao.loadTurnos();
        } catch (ClassNotFoundException | IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * Obtiene la lista de especialistas.
     * 
     * @return la lista de especialistas.
     */
    public List<PersonaDTO> getEspecialistas() {
        List<PersonaDTO> especialistas = new ArrayList<>();
        for (Persona persona : personas) {
            if (persona.getTipoCuenta().equals("Especialista")) {
                especialistas.add(DataMapper.toPersonaDTO(persona));
            }
        }
        return especialistas;
    }

    /**
     * Obtiene la lista de turnos en formato DTO.
     * 
     * @return la lista de turnos en formato DTO.
     */
    public List<TurnoDTO> getTurnos() {
        List<TurnoDTO> turnosDto = new ArrayList<>();
        for (Turno turno : turnos) {
            turnosDto.add(DataMapper.toTurnoDTO(turno));
        }

        turnosDto.sort((turno1, turno2) -> turno1.getFecha().compareTo(turno2.getFecha()));
        return turnosDto;
    }

    /**
     * Guarda la lista de personas.
     */
    public void savePersonas() {
        try {
            this.personaDao.savePersonas(personas);
        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Guarda la lista de turnos.
     */
    public void saveTurnos() {
        try {
            this.turnoDao.saveTurnos(turnos);
        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }
}
