package co.edu.unbosque.model;


public class DataMapper {
	public static PersonaDTO toPersonaDTO(Persona persona) {
		PersonaDTO personaDTO = new PersonaDTO(persona.getId(), persona.getNombre(), persona.getCorreo(), persona.getTipoCuenta());
		if (persona instanceof Especialista) {
			personaDTO.setArea(((Especialista) persona).getArea().name());
		}
		return personaDTO;
	}
	
	public static Persona toPersona(PersonaDTO personaDTO) {
		Persona persona = new Persona(personaDTO.getId(), personaDTO.getNombre(), personaDTO.getCorreo(), personaDTO.getTipoCuenta());
		if (personaDTO.getArea() != null) {
			Especialista especialista = new Especialista(personaDTO.getId(), personaDTO.getNombre(), personaDTO.getCorreo(), personaDTO.getTipoCuenta());
			especialista.setArea(Area.valueOf(personaDTO.getArea()));
			persona = especialista;
		}
		return persona;
	}

	public static CitaDTO toCitaDTO(Cita cita) {
		CitaDTO citaDTO = new CitaDTO();
		citaDTO.setId(cita.getId());
		citaDTO.setPaciente(toPersonaDTO(cita.getPaciente()));
		citaDTO.setEspecialista(toPersonaDTO(cita.getEspecialista()));
		citaDTO.setFechaHora(cita.getFechaHora());
		citaDTO.setArea(cita.getArea().name());
		return citaDTO;
	}

	private static Especialista toEspecialista(PersonaDTO personaDTO) {
		Especialista especialista = new Especialista(personaDTO.getId(), personaDTO.getNombre(), personaDTO.getCorreo(), personaDTO.getTipoCuenta());
		especialista.setArea(Area.valueOf(personaDTO.getArea()));
		return especialista;
	}

	private static Paciente toPaciente(PersonaDTO personaDTO) {
		Paciente paciente = new Paciente(personaDTO.getId(), personaDTO.getNombre(), personaDTO.getCorreo(), personaDTO.getTipoCuenta());
		return paciente;
	}

	public static Cita toCita(CitaDTO citaDTO) {
		Cita cita = new Cita();
		cita.setId(citaDTO.getId());

		Especialista especialista = new Especialista(
			citaDTO.getEspecialista().getId(), 
			citaDTO.getEspecialista().getNombre(), 
			citaDTO.getEspecialista().getCorreo(), 
			"Especialista"
		);
		especialista.setArea(Area.valueOf(citaDTO.getArea()));

		Paciente paciente = new Paciente(
			citaDTO.getPaciente().getId(), 
			citaDTO.getPaciente().getNombre(), 
			citaDTO.getPaciente().getCorreo(), 
			"Paciente"
		);

		cita.setPaciente(paciente);
		cita.setEspecialista(especialista);
		cita.setFechaHora(citaDTO.getFechaHora());
		cita.setArea(Area.valueOf(citaDTO.getArea()));
		return cita;
	}

	public static TurnoDTO toTurnoDTO(Turno turno) {
		TurnoDTO turnoDTO = new TurnoDTO();
		turnoDTO.setId(turno.getId());
		turnoDTO.setArea(turno.getArea().name());
		turnoDTO.setEspecialista(toPersonaDTO(turno.getEspecialista()));
		turnoDTO.setFecha(turno.getFecha());
		for (Cita cita : turno.getCitas()) {
			turnoDTO.getCitas().add(toCitaDTO(cita));
		}
		return turnoDTO;
	}

	public static Turno toTurno(TurnoDTO turnoDTO) {
		Turno turno = new Turno();
		turno.setId(turnoDTO.getId());
		turno.setArea(Area.valueOf(turnoDTO.getArea()));
		turno.setEspecialista(toEspecialista(turnoDTO.getEspecialista()));
		turno.setFecha(turnoDTO.getFecha());
		for (CitaDTO citaDTO : turnoDTO.getCitas()) {
			turno.getCitas().add(toCita(citaDTO));
		}
		return turno;
	}

	public static CitaDisponibleDTO toCitaDisponibleDTO(CitaDisponible citaDisponible) {
		CitaDisponibleDTO citaDisponibleDTO = new CitaDisponibleDTO();
		citaDisponibleDTO.setHora(citaDisponible.getHora());
		citaDisponibleDTO.setTurnoId(citaDisponible.getTurno().getId());
		citaDisponibleDTO.setEspecialista(toPersonaDTO(citaDisponible.getEspecialista()));
		return citaDisponibleDTO;
	}
}
