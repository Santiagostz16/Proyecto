package co.edu.unbosque.model;


public class DirectorMedico extends Persona {
    private static final long serialVersionUID = 1L;
    public DirectorMedico(String id, String nombre, String correo, String tipoCuenta) {
		super(id, nombre, correo, tipoCuenta);
	}
}
