package co.edu.unbosque.model;

public class Especialista extends Persona {
	private static final long serialVersionUID = 1L;
	Area area;
	
	public Especialista(String id, String nombre, String correo, String tipoCuenta) {
		super(id, nombre, correo, tipoCuenta);
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}
}
