package co.edu.unbosque.model;
import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * Clase Notificador para enviar correos electrónicos.
 */
public class Notificador {
    Session session;
    String fromEmail;

    /**
     * Constructor de la clase Notificador.
     * 
     * @param fromEmail el correo electrónico del remitente.
     * @param password la contraseña del correo electrónico del remitente.
     */
    public Notificador(String fromEmail, String password) {
        this.fromEmail = fromEmail;
        Properties props = new java.util.Properties();
        props.put("mail.smtp.host", "smtp.gmail.com"); 
		props.put("mail.smtp.port", "587"); 
		props.put("mail.smtp.auth", "true"); 
		props.put("mail.smtp.starttls.enable", "true");
        Authenticator auth = new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, password);
            }
        };

        this.session = Session.getDefaultInstance(props, auth);
    }

    /**
     * Envía un correo electrónico.
     * 
     * @param correo el correo electrónico del destinatario.
     * @param asunto el asunto del correo.
     * @param mensaje el mensaje del correo.
     */
    public void enviarCorreo(String correo, String asunto, String mensaje) {
        sendEmail(correo,asunto, mensaje);
    }

    /**
     * Método privado para enviar un correo electrónico.
     * 
     * @param toEmail el correo electrónico del destinatario.
     * @param subject el asunto del correo.
     * @param body el cuerpo del correo.
     */
    private void sendEmail(String toEmail, String subject, String body){
		try
	    {
	      MimeMessage msg = new MimeMessage(this.session);
	      msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
	      msg.addHeader("format", "flowed");
	      msg.addHeader("Content-Transfer-Encoding", "8bit");
	      msg.setFrom(new InternetAddress(this.fromEmail, this.fromEmail));
	      msg.setReplyTo(InternetAddress.parse(this.fromEmail, false));
	      msg.setSubject(subject, "UTF-8");
	      msg.setText(body, "UTF-8");
	      msg.setSentDate(new Date());
	      msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail, false));
    	  Transport.send(msg);  
        }
	    catch (Exception e) {
	      e.printStackTrace();
	    }
	}
}
