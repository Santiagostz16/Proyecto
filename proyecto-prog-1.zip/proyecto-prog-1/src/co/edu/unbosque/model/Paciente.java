package co.edu.unbosque.model;

import java.io.Serializable;

public class Paciente extends Persona  implements Serializable {
	private static final long serialVersionUID = 1L;
	public Paciente(String id, String nombre, String correo, String tipoCuenta) {
		super(id, nombre, correo, tipoCuenta);
	}
}
