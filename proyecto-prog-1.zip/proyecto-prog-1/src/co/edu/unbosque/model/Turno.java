package co.edu.unbosque.model;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase Turno que representa un turno de un especialista.
 */
public class Turno implements Serializable {
	private static final long serialVersionUID = 1L;
	String id;
	Area area;
	Especialista especialista;
	LocalDate fecha;
	List<Cita> citas;

	/**
	 * Constructor de la clase Turno.
	 */
	public Turno() {
		this.citas = new ArrayList<>();
	}

	/**
	 * Agrega una cita al turno.
	 * 
	 * @param cita la cita a agregar.
	 * @throws IllegalArgumentException si ya existe una cita a la misma hora.
	 */
	public void agregarCita(Cita cita) {
		for (Cita c : citas) {
			if (c.getFechaHora().equals(cita.getFechaHora())) {
				throw new IllegalArgumentException("Ya existe una cita a esa hora.");
			}
		}
		this.citas.add(cita);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Genera el texto del email para el turno.
	 * 
	 * @return el texto del email.
	 */
	public String textoEmail() {
		return "Turno: " + id + "\n" + "Fecha: " + fecha + "\n" + "Especialista: " + especialista.getNombre() + "\n"
				+ "Correo: " + especialista.getCorreo() + "\n" + "Area: " + area + "\n";
	}

	/**
	 * Obtiene los horarios disponibles para citas en el turno.
	 * 
	 * @return la lista de horarios disponibles.
	 */
	public List<CitaDisponible> obtenerHorariosDisponibles() {
		List<CitaDisponible> citasDisponible = new ArrayList<>();
		LocalTime inicio = LocalTime.of(0, 0); // Hora de inicio de las citas
		LocalTime fin = LocalTime.of(23, 0); // Hora de fin de las citas
		Duration intervalo = Duration.ofMinutes(60); // Duración de cada cita

		while (inicio.isBefore(fin)) {
			boolean ocupado = false;
			for (Cita c : citas) {
				if (c.getFechaHora().toLocalTime().equals(inicio) && !c.getEsCancelada()) {
					ocupado = true;
					break;
				}
			}
			if (!ocupado) {
				CitaDisponible citaDisponible = new CitaDisponible();
				citaDisponible.setEspecialista(especialista);
				citaDisponible.setHora(fecha.atTime(inicio));
				citaDisponible.setTurno(this);
				citasDisponible.add(citaDisponible);
			}
			inicio = inicio.plus(intervalo);
		}
		return citasDisponible;
	}
	public Area getArea() {
		return area;
	}
	public void setArea(Area area) {
		this.area = area;
	}
	public Especialista getEspecialista() {
		return especialista;
	}
	public void setEspecialista(Especialista especialista) {
		this.especialista = especialista;
	}
	public LocalDate getFecha() {
		return fecha;
	}
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}
	public List<Cita> getCitas() {
		return citas;
	}
	public void setCitas(List<Cita> citas) {
		this.citas = citas;
	}
}
