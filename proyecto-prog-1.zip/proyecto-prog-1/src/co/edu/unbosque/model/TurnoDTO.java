package co.edu.unbosque.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TurnoDTO {
	String id;
	String area;
	PersonaDTO especialista;
	LocalDate fecha;
	List<CitaDTO> citas;


	public TurnoDTO() {
		this.citas = new ArrayList<>();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public PersonaDTO getEspecialista() {
		return especialista;
	}

	public void setEspecialista(PersonaDTO especialista) {
		this.especialista = especialista;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public List<CitaDTO> getCitas() {
		return citas;
	}

	public void setCitas(List<CitaDTO> citas) {
		this.citas = citas;
	}



}
