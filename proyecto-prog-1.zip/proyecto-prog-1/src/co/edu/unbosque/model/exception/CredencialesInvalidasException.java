package co.edu.unbosque.model.exception;


public class CredencialesInvalidasException extends Exception {
	public CredencialesInvalidasException(String msgFl) {
		super(msgFl);
	}
}
