package co.edu.unbosque.model.exception;

public class TurnoConsecutivoException extends Exception {
    public TurnoConsecutivoException(String message) {
        super(message);
    }
}
