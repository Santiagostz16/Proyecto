package co.edu.unbosque.model.exception;

public class TurnoYaExistenteException extends Exception {
    public TurnoYaExistenteException(String message) {
        super(message);
    }
}