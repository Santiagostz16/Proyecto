package co.edu.unbosque.model.exception;

public class TurnosSemanalesExcedidosException extends Exception {
    public TurnosSemanalesExcedidosException(String message) {
        super(message);
    }
}
