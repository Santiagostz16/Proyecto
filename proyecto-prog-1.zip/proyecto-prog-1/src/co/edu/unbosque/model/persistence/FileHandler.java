package co.edu.unbosque.model.persistence;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import co.edu.unbosque.model.Persona;
import co.edu.unbosque.model.Turno;

/**
 * Clase FileHandler para manejar operaciones de lectura y escritura de archivos.
 */
public class FileHandler {
    /**
     * Escribe una lista de personas en un archivo.
     * 
     * @param nombreArchivo el nombre del archivo.
     * @param personas la lista de personas a escribir.
     * @throws IOException si ocurre un error de entrada/salida.
     */
    public void escribirArchivoPersonas(String nombreArchivo, List<Persona> personas) throws IOException {
        File file = new File(nombreArchivo);
        if (!file.exists()) {
            file.createNewFile();
        }

        FileOutputStream fileOutputStream = new FileOutputStream(file);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(personas);
        objectOutputStream.close();
        fileOutputStream.close();
    }

    /**
     * Lee una lista de personas desde un archivo.
     * 
     * @param nombreArchivo el nombre del archivo.
     * @return la lista de personas leída.
     * @throws IOException si ocurre un error de entrada/salida.
     * @throws ClassNotFoundException si la clase no se encuentra.
     */
    public List<Persona> leerArchivoPersonas(String nombreArchivo) throws IOException, ClassNotFoundException {
        File file = new File(nombreArchivo);
        if (file.exists()) {
            FileInputStream fileInputStream = new FileInputStream(file);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            List<Persona> personas = (List<Persona>) objectInputStream.readObject();
            fileInputStream.close();
            objectInputStream.close();
            return personas;
        }
        return new ArrayList<Persona>();
    }

    /**
     * Escribe una lista de turnos en un archivo.
     * 
     * @param nombreArchivo el nombre del archivo.
     * @param turnos la lista de turnos a escribir.
     * @throws IOException si ocurre un error de entrada/salida.
     */
    public void escribirArchivoTurnos(String nombreArchivo, List<Turno> turnos) throws IOException {
        File file = new File(nombreArchivo);
        if (!file.exists()) {
            file.createNewFile();
        }

        FileOutputStream fileOutputStream = new FileOutputStream(file);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(turnos);
        objectOutputStream.close();
        fileOutputStream.close();
    }

    /**
     * Lee una lista de turnos desde un archivo.
     * 
     * @param nombreArchivo el nombre del archivo.
     * @return la lista de turnos leída.
     * @throws IOException si ocurre un error de entrada/salida.
     * @throws ClassNotFoundException si la clase no se encuentra.
     */
    public List<Turno> leerArchivoTurnos(String nombreArchivo) throws IOException, ClassNotFoundException {
        File file = new File(nombreArchivo);
        if (file.exists()) {
            FileInputStream fileInputStream = new FileInputStream(file);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            List<Turno> personas = (List<Turno>) objectInputStream.readObject();
            fileInputStream.close();
            objectInputStream.close();
            return personas;
        }
        return new ArrayList<Turno>();
    }

    /**
     * Lee propiedades desde un archivo.
     * 
     * @param nombreArchivo el nombre del archivo.
     * @return las propiedades leídas.
     */
    public Properties leerPropiedades(String nombreArchivo) {
        Properties properties = new Properties();
        
        try {
            properties.load(new FileInputStream(nombreArchivo));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return properties;
    }

    /**
     * Lee un archivo de texto y retorna una lista de líneas.
     * 
     * @param nombreArchivo el nombre del archivo.
     * @return la lista de líneas leída.
     */
    public List<String> leerArchivoTexto(String nombreArchivo) {
        Path path = Paths.get(nombreArchivo);
        try {
            List<String> lines = Files.readAllLines(path);
            return lines;
        } catch (IOException e) {
            // Si el archivo no existe, retornar una lista vacía
            return new ArrayList<String>();
        }
    }

}
