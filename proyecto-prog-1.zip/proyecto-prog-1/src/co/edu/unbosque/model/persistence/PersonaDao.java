package co.edu.unbosque.model.persistence;

import java.io.IOException;
import java.util.List;

import co.edu.unbosque.model.Persona;

public interface PersonaDao {
    public void savePersonas(List<Persona> personas) throws ClassNotFoundException, IOException;
	public List<Persona> loadPersonas() throws ClassNotFoundException, IOException;
}
