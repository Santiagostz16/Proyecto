package co.edu.unbosque.model.persistence;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import co.edu.unbosque.model.Area;
import co.edu.unbosque.model.DirectorMedico;
import co.edu.unbosque.model.Especialista;
import co.edu.unbosque.model.Paciente;
import co.edu.unbosque.model.Persona;

public class PersonaDaoImpl  implements PersonaDao {
    private static final String ARCHIVO_NAME = "persona.data";
	private FileHandler fileHandler;

	public PersonaDaoImpl() {
		this.fileHandler = new FileHandler();
	}

	public void savePersonas(List<Persona> personas) throws ClassNotFoundException, IOException {
		fileHandler.escribirArchivoPersonas(ARCHIVO_NAME, personas);
	}

	public List<Persona> loadPersonas() throws ClassNotFoundException, IOException {
		List<Persona> personas = fileHandler.leerArchivoPersonas(ARCHIVO_NAME);
		return personas;
	}

	public List<Persona> loadPersonasFromTextFile(String archivoName) {
		List<Persona> personas = new ArrayList<>();
		List<String> rows = this.fileHandler.leerArchivoTexto(archivoName);
		for (String row : rows) {
			personas.add(rowToProducto(row));
		}

		return personas;
	}

	private Persona rowToProducto(String row) {
		String[] valores = row.split("::");

		String id = valores[0];
		String nombre = valores[1];
		String correo = valores[2];
		String tipoCuenta = valores[3];

		switch (tipoCuenta) {
			case "Paciente":
				return new Paciente(id, nombre, correo, tipoCuenta);				
				
			case "Especialista":
				Especialista especialista =  new Especialista(id, nombre, correo, tipoCuenta);
				String area = valores[4];
				especialista.setArea(Area.valueOf(area));
				return especialista;
								
			case "Director Medico": 
				return new DirectorMedico(id, nombre, correo, tipoCuenta);
		}
		Persona producto = new Persona(id, nombre, correo, tipoCuenta);

		return producto;
	}
}
