package co.edu.unbosque.model.persistence;

import java.util.Properties;

/**
 * Interfaz PropiedadesDao para manejar la persistencia de propiedades.
 */
public interface PropiedadesDao {
	/**
	 * Carga las propiedades desde un archivo.
	 * 
	 * @return las propiedades cargadas.
	 */
	public Properties load();
}
