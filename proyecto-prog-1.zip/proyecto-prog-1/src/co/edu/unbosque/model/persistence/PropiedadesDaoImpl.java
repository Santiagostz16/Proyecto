package co.edu.unbosque.model.persistence;

import java.util.Properties;

/**
 * Implementación de la interfaz PropiedadesDao para manejar la persistencia de propiedades.
 */
public class PropiedadesDaoImpl implements PropiedadesDao {
    private static final String ARCHIVO_NAME = "propiedades.txt";
	private FileHandler fileHandler;

	/**
	 * Constructor de la clase PropiedadesDaoImpl.
	 */
	public PropiedadesDaoImpl() {
		this.fileHandler = new FileHandler();
	}

	/**
	 * Carga las propiedades desde un archivo.
	 * 
	 * @return las propiedades cargadas.
	 */
	@Override
	public Properties load() {
		Properties properties = this.fileHandler.leerPropiedades(ARCHIVO_NAME);
		return properties;
	}
}
