package co.edu.unbosque.model.persistence;

import java.io.IOException;
import java.util.List;

import co.edu.unbosque.model.Turno;

/**
 * Interfaz TurnoDao para manejar la persistencia de turnos.
 */
public interface TurnoDao {
	/**
	 * Guarda la lista de turnos en un archivo.
	 * 
	 * @param turnos la lista de turnos a guardar.
	 * @throws ClassNotFoundException si la clase no se encuentra.
	 * @throws IOException si ocurre un error de entrada/salida.
	 */
    public void saveTurnos(List<Turno> turnos) throws ClassNotFoundException, IOException;

	/**
	 * Carga la lista de turnos desde un archivo.
	 * 
	 * @return la lista de turnos cargada.
	 * @throws ClassNotFoundException si la clase no se encuentra.
	 * @throws IOException si ocurre un error de entrada/salida.
	 */
	public List<Turno> loadTurnos() throws ClassNotFoundException, IOException;
}
