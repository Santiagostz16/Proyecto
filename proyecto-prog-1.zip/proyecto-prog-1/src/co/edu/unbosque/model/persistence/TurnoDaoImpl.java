package co.edu.unbosque.model.persistence;

import java.io.IOException;
import java.util.List;

import co.edu.unbosque.model.Turno;

/**
 * Implementación de la interfaz TurnoDao para manejar la persistencia de turnos.
 */
public class TurnoDaoImpl implements TurnoDao {
    private static final String ARCHIVO_NAME = "turno.data";
	private FileHandler fileHandler;

	/**
	 * Constructor de la clase TurnoDaoImpl.
	 */
	public TurnoDaoImpl() {
		this.fileHandler = new FileHandler();
	}

	/**
	 * Guarda la lista de turnos en un archivo.
	 * 
	 * @param turnos la lista de turnos a guardar.
	 * @throws ClassNotFoundException si la clase no se encuentra.
	 * @throws IOException si ocurre un error de entrada/salida.
	 */
	public void saveTurnos(List<Turno> turnos) throws ClassNotFoundException, IOException {
		fileHandler.escribirArchivoTurnos(ARCHIVO_NAME, turnos);
	}

	/**
	 * Carga la lista de turnos desde un archivo.
	 * 
	 * @return la lista de turnos cargada.
	 * @throws ClassNotFoundException si la clase no se encuentra.
	 * @throws IOException si ocurre un error de entrada/salida.
	 */
	public List<Turno> loadTurnos() throws ClassNotFoundException, IOException {
		List<Turno> turnos = fileHandler.leerArchivoTurnos(ARCHIVO_NAME);
		return turnos;
	}
}
