package co.edu.unbosque.model.tests;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import co.edu.unbosque.model.Clinica;
import co.edu.unbosque.model.Persona;
import co.edu.unbosque.model.PersonaDTO;
import co.edu.unbosque.model.exception.CredencialesInvalidasException;

public class ClinicaTest {
	private Clinica clinica;

	@Before
	public void setUp() {
		clinica = new Clinica();
	}

	@Test
	public void testAgregarPersona() {
		PersonaDTO personaDto = new PersonaDTO("123", "John", "example@mail.com", "Paciente");
		clinica.agregarPersona(personaDto);

		List<Persona> personas = clinica.getPersonas();
		assertEquals(1, personas.size());
		assertEquals("123", personas.get(0).getId());
		assertEquals("John", personas.get(0).getNombre());
		assertEquals("example@mail.com", personas.get(0).getCorreo());
		assertEquals("Paciente", personas.get(0).getTipoCuenta());
	}

	@Test
	public void testValidarCredeniales() throws CredencialesInvalidasException {
		PersonaDTO personaDto = new PersonaDTO("123", "John", "example@mail.com", "password");
		clinica.agregarPersona(personaDto);

		PersonaDTO result = clinica.validarCredeniales("example@mail.com", "example@mail.com");
		assertNotNull(result);
		assertEquals("123", result.getId());
		assertEquals("John", result.getNombre());
		assertEquals("example@mail.com", result.getCorreo());
	}

	@Test(expected = CredencialesInvalidasException.class)
	public void testValidarCredenialesInvalid() throws CredencialesInvalidasException {
		PersonaDTO personaDto = new PersonaDTO("123", "John", "example@mail.com", "password");
		clinica.agregarPersona(personaDto);

		clinica.validarCredeniales("example@mail.com", "wrongpassword");

	}

}
