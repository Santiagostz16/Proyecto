package co.edu.unbosque.view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import co.edu.unbosque.model.CitaDisponible;

public class PacientePrincipalPanel  extends JPanel {
    private static final long serialVersionUID = 1L;
    private ActionListener listener;
	private JTextField nombreField;
    private JTextField telefonoField;
    private JTextField correoField;
    private JButton agregarButton;
    private JButton eliminarButton;
    private JButton buscarButton;
    private JTable contactosTable;

    public PacientePrincipalPanel(ActionListener listener) {
        this.listener = listener;
        setLayout(new BorderLayout());

        // Panel de entrada
        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        inputPanel.add(new JLabel("Nombre:"));
        nombreField = new JTextField();
        inputPanel.add(nombreField);

        inputPanel.add(new JLabel("Teléfono:"));
        telefonoField = new JTextField();
        telefonoField.setDocument(new javax.swing.text.PlainDocument() {
            @Override
            public void insertString(int offs, String str, javax.swing.text.AttributeSet a) throws javax.swing.text.BadLocationException {
            if (str == null) {
                return;
            }
            for (char c : str.toCharArray()) {
                if (!Character.isDigit(c)) {
                return;
                }
            }
            super.insertString(offs, str, a);
            }
        });
        inputPanel.add(telefonoField);

        inputPanel.add(new JLabel("Correo:"));
        correoField = new JTextField();
        inputPanel.add(correoField);

        // Panel de botones
        JPanel buttonPanel = new JPanel();
        agregarButton = new JButton("Agregar");
		agregarButton.setActionCommand("CREAR_CONTACTO");
		agregarButton.addActionListener(listener);

        eliminarButton = new JButton("Eliminar");
        eliminarButton.setActionCommand("ELIMINAR_CONTACTO");
        eliminarButton.addActionListener(listener);

        buscarButton = new JButton("Buscar");
        buscarButton.setActionCommand("BUSCAR_CONTACTO");
        buscarButton.addActionListener(listener);


        buttonPanel.add(agregarButton);
        buttonPanel.add(eliminarButton);
        buttonPanel.add(buscarButton);

        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);

        // Tabla para mostrar contactos
        contactosTable = new JTable(); // Configuración de JTable para mostrar contactos

        add(new JScrollPane(contactosTable), BorderLayout.SOUTH);
    }

    public JTextField getNombreField() {
        return nombreField;
    }

    public JTextField getTelefonoField() {
        return telefonoField;
    }

    public JTextField getCorreoField() {
        return correoField;
    }

    public JButton getAgregarButton() {
        return agregarButton;
    }

    public JButton getEliminarButton() {
        return eliminarButton;
    }

    public JButton getBuscarButton() {
        return buscarButton;
    }

    public JTable getContactosTable() {
        return contactosTable;
    }

    public void actualizarTabla(List<CitaDisponible> citasDisponible) {
		String[] columnas = {"Fecha/Hora","Especialista", "Area"};
		Object[][] datos = new Object[citasDisponible.size()][3];
		
		int i = 0;
		for (CitaDisponible contacto: citasDisponible) {
			datos[i][0] = contacto.getHora();
			datos[i][1] = contacto.getEspecialista().getNombre();
			datos[i][2] = contacto.getEspecialista().getArea();
			i++;
		}

		contactosTable.setModel(new javax.swing.table.DefaultTableModel(datos, columnas));
	}
}
