package co.edu.unbosque.view;

import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.github.lgooddatepicker.components.DatePicker;

import co.edu.unbosque.model.PersonaDTO;
import co.edu.unbosque.model.TurnoDTO;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

public class PanelDirectorMedico extends JPanel  {
    JComboBox<String> especialistaComboBox;
    List<PersonaDTO> especialitas;
    DatePicker fechaDatePicker;
    JTable turnosTable;

    public PanelDirectorMedico(ActionListener listener) {

        String[] columnNames = {"Fecha", "Especialista", "Área"};
        Object[][] data = {}; 

        turnosTable = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(turnosTable);

        JButton addButton = new JButton("Agregar Turno");
        addButton.addActionListener(listener);
        addButton.setActionCommand("AGREGAR_TURNO");

        JLabel dateLabel = new JLabel("Fecha:");
        fechaDatePicker = new DatePicker();

        JLabel specialistLabel = new JLabel("Especialista:");
        especialistaComboBox = new JComboBox<>(new String[]{"Especialista 1", "Especialista 2"});

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(dateLabel, gbc);

        gbc.gridx = 1;
        add(fechaDatePicker, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(specialistLabel, gbc);

        gbc.gridx = 1;
        add(especialistaComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        add(addButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        add(scrollPane, gbc);
    }

    public JComboBox<String> getEspecialistaComboBox() {
        return especialistaComboBox;
    }

    public List<PersonaDTO> getEspecialitas() {
        return especialitas;
    }

    public void setEspecialitas(List<PersonaDTO> especialitas) {
        this.especialitas = especialitas;
        especialistaComboBox.removeAllItems();
        for (PersonaDTO especialista : especialitas) {
            especialistaComboBox.addItem(especialista.getNombre() + " [" + especialista.getArea() + ']');
        }
    }

    public void actualizarTurnosTable(List<TurnoDTO> turnos) {
		String[] columnas = {"Fecha","Especialista", "Area"};
		Object[][] datos = new Object[turnos.size()][3];
		
		int i = 0;
		for (TurnoDTO turno: turnos) {
			datos[i][0] = turno.getFecha();
			datos[i][1] = turno.getEspecialista().getNombre();
			datos[i][2] = turno.getEspecialista().getArea();
			i++;
		}

		turnosTable.setModel(new javax.swing.table.DefaultTableModel(datos, columnas));
	}

    public DatePicker getFechaDatePicker() {
        return fechaDatePicker;
    }

    public void setFechaDatePicker(DatePicker fechaDatePicker) {
        this.fechaDatePicker = fechaDatePicker;
    }

}
