package co.edu.unbosque.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import co.edu.unbosque.model.CitaDTO;
import co.edu.unbosque.model.CitaDisponibleDTO;

public class PanelEspecialistaPrincipal extends JPanel  {

    List<CitaDisponibleDTO> citas;
    JTable citasTable;

    public PanelEspecialistaPrincipal(ActionListener listener) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JPanel botonesTabla = new JPanel();
        botonesTabla.setMaximumSize(new Dimension(500, 300));
        
        String[] columnNames = {"Fecha","Paciente"};
        Object[][] data = {};
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        citasTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(citasTable);
        JLabel label = new JLabel("Citas Asignadas");
        botonesTabla.add(label, BorderLayout.NORTH);
        botonesTabla.add(scrollPane, BorderLayout.CENTER);
        add(botonesTabla);
    }

    public void actualizarCitasTable(List<CitaDTO> citas) {
		String[] columnas = {"Fecha","Paciente"};
		Object[][] datos = new Object[citas.size()][2];
		
		int i = 0;
		for (CitaDTO cita: citas) {
			datos[i][0] = cita.getFechaHora();
			datos[i][1] = cita.getPaciente().getNombre();
			i++;
		}

		citasTable.setModel(new javax.swing.table.DefaultTableModel(datos, columnas));
    }
}
