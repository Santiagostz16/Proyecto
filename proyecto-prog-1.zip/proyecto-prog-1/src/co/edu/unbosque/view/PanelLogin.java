package co.edu.unbosque.view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelLogin extends JPanel {
    private JTextField emailField;
    private JPasswordField passwordField;
    private JComboBox<String> accountTypeComboBox;
    private JButton loginButton;

    public PanelLogin(ActionListener listener) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel emailLabel = new JLabel("Email:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(emailLabel, gbc);

        emailField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 0;
        add(emailField, gbc);

        JLabel passwordLabel = new JLabel("Contraseña:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(passwordLabel, gbc);

        passwordField = new JPasswordField(20);
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(passwordField, gbc);

        JLabel accountTypeLabel = new JLabel("Tipo de cuenta:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(accountTypeLabel, gbc);

        String[] accountTypes = {"Paciente", "Especialista", "Director Medico"};
        accountTypeComboBox = new JComboBox<>(accountTypes);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(accountTypeComboBox, gbc);

        loginButton = new JButton("Login");
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(loginButton, gbc);
        loginButton.setActionCommand("LOGIN");
		loginButton.addActionListener(listener);
    }

    public String getEmail() {
        return emailField.getText();
    }

    public String getPassword() {
        return new String(passwordField.getPassword());
    }

    public String getAccountType() {
        return (String) accountTypeComboBox.getSelectedItem();
    }

    public JButton getLoginButton() {
        return loginButton;
    }
}