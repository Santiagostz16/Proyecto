package co.edu.unbosque.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import co.edu.unbosque.model.CitaDisponibleDTO;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.util.List;

public class PanelPacienteAgendarCita extends JPanel {
    List<CitaDisponibleDTO> citaDisponible;
    JTable citaDisponibleTable;

    public PanelPacienteAgendarCita(ActionListener listener) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JPanel botonesTabla = new JPanel();
        botonesTabla.setMaximumSize(new Dimension(500, 300));
        
        String[] columnNames = {"Fecha","Especialista", "Area"};
        Object[][] data = {};
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        citaDisponibleTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(citaDisponibleTable);
        JLabel label = new JLabel("Citas Disponibles");
        botonesTabla.add(label, BorderLayout.NORTH);
        botonesTabla.add(scrollPane, BorderLayout.CENTER);
        add(botonesTabla);


        
        JPanel botonesPanel = new JPanel();
        botonesPanel.setLayout(new BoxLayout(botonesPanel, BoxLayout.X_AXIS));

        JButton agendarCitaButton = new JButton("Agendar Cita");
        agendarCitaButton.setActionCommand("AGENDAR_CITA");
        agendarCitaButton.addActionListener(listener);
        botonesPanel.add(agendarCitaButton);

        JButton cancelarCitaButton = new JButton("Cancelar");
        cancelarCitaButton.setActionCommand("MOSTRAR_PRINCIPAL_PACIENTE");
        cancelarCitaButton.addActionListener(listener);
        botonesPanel.add(cancelarCitaButton);

        add(botonesPanel);

    }

    public List<CitaDisponibleDTO> getCitaDisponible() {
        return citaDisponible;
    }

    public void setCitaDisponible(List<CitaDisponibleDTO> citaDisponible) {
        this.citaDisponible = citaDisponible;
    }


    public JTable getCitaDisponibleTable() {
        return citaDisponibleTable;
    }

    public void setCitaDisponibleTable(JTable citaDisponibleTable) {
        this.citaDisponibleTable = citaDisponibleTable;
    }

    public void actualizarCitaDisponibleTable(List<CitaDisponibleDTO> citaDisponible) {
		String[] columnas = {"Fecha","Especialista", "Area"};
		Object[][] datos = new Object[citaDisponible.size()][3];
		
		int i = 0;
		for (CitaDisponibleDTO cita: citaDisponible) {
			datos[i][0] = cita.getHora();
			datos[i][1] = cita.getEspecialista().getNombre();
			datos[i][2] = cita.getEspecialista().getArea();
			i++;
		}

		citaDisponibleTable.setModel(new javax.swing.table.DefaultTableModel(datos, columnas));
	}
}
