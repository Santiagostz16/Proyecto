package co.edu.unbosque.view;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Dimension;

import co.edu.unbosque.model.CitaDTO;


public class PanelPacientePrincipal extends JPanel {
    private JTable proximasCitasTable;
    private JTable citasAnterioresTable;

    public PanelPacientePrincipal(ActionListener listener) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        
        JPanel botonesPanel = new JPanel();
        botonesPanel.setMaximumSize(new Dimension(400, 100));
        JButton agendarCitaButton = new JButton("Agendar Cita");
        agendarCitaButton.setActionCommand("MOSTRAR_AGENDAR_CITA");
        agendarCitaButton.addActionListener(listener);
        botonesPanel.add(agendarCitaButton);
        add(botonesPanel);

        JPanel citasAnterioresPanel = new JPanel();
        citasAnterioresPanel.setMaximumSize(new Dimension(400, 100));
        citasAnterioresPanel.setLayout(new BorderLayout());
        String[] columnNamesPasadas = {"Fecha y Hora", "Nombre del Medico", "Area"};
        Object[][] dataPasadas = {};
        DefaultTableModel modelPasadas = new DefaultTableModel(dataPasadas, columnNamesPasadas);
        citasAnterioresTable = new JTable(modelPasadas);
        JScrollPane scrollPanePasadas = new JScrollPane(citasAnterioresTable);
        citasAnterioresPanel.add(new javax.swing.JLabel("Citas anteriores"), BorderLayout.NORTH);
        citasAnterioresPanel.add(scrollPanePasadas, BorderLayout.CENTER);
        add(citasAnterioresPanel);

        JPanel citasProximasPanel = new JPanel();
        citasProximasPanel.setMaximumSize(new Dimension(400, 200));
        citasProximasPanel.setLayout(new BorderLayout());
        String[] columnNames = {"Fecha y Hora", "Nombre del Medico", "Area"};
        Object[][] data = {};
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        proximasCitasTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(proximasCitasTable);
        citasProximasPanel.add(new javax.swing.JLabel("Citas próximas"), BorderLayout.NORTH);
        citasProximasPanel.add(scrollPane, BorderLayout.CENTER);
        JButton cancelarCitaButton = new javax.swing.JButton("Cancelar Cita");
        cancelarCitaButton.setActionCommand("CANCELAR_CITA");
        cancelarCitaButton.addActionListener(listener);
        citasProximasPanel.add(cancelarCitaButton, BorderLayout.SOUTH);
        add(citasProximasPanel);
    }

    public JTable getProximasCitasTable() {
        return proximasCitasTable;
    }

    public void setProximasCitasTable(JTable proximasCitasTable) {
        this.proximasCitasTable = proximasCitasTable;
    }

    public void actualizarProximasCitasTable(List<CitaDTO> citas) {
        String[] columnas = {"Fecha y Hora", "Nombre del Medico", "Area", "ID"};
		Object[][] datos = new Object[citas.size()][4];
		
		int i = 0;
		for (CitaDTO cita: citas) {
			datos[i][0] = cita.getFechaHora().toString();
			datos[i][1] = cita.getEspecialista().getNombre();
			datos[i][2] = cita.getArea();
            datos[i][3] = cita.getId();
			i++;
		}


		this.proximasCitasTable.setModel(new javax.swing.table.DefaultTableModel(datos, columnas));
        this.proximasCitasTable.removeColumn(this.proximasCitasTable.getColumnModel().getColumn(3));
    }   


    public void actualizarcitasAnterioresTable(List<CitaDTO> citas) {
        String[] columnas = {"Fecha y Hora", "Nombre del Medico", "Area", "ID"};
		Object[][] datos = new Object[citas.size()][4];
		
		int i = 0;
		for (CitaDTO cita: citas) {
			datos[i][0] = cita.getFechaHora().toString();
			datos[i][1] = cita.getEspecialista().getNombre();
			datos[i][2] = cita.getArea();
            datos[i][3] = cita.getId();
			i++;
		}


		this.citasAnterioresTable.setModel(new javax.swing.table.DefaultTableModel(datos, columnas));
        this.citasAnterioresTable.removeColumn(this.citasAnterioresTable.getColumnModel().getColumn(3));
    }  
}
