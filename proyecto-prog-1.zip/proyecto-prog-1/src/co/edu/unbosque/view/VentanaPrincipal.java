package co.edu.unbosque.view;

import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import co.edu.unbosque.model.CitaDTO;
import co.edu.unbosque.model.CitaDisponibleDTO;
import co.edu.unbosque.model.PersonaDTO;
import co.edu.unbosque.model.TurnoDTO;

/**
 * Clase VentanaPrincipal que representa la ventana principal de la aplicación.
 */
public class VentanaPrincipal extends JFrame {
	private ActionListener listener;
	private PanelLogin panelLogin;
	private PanelPacientePrincipal panelPacientePrincipal;
	private PanelPacienteAgendarCita panelPacienteAgendarCita;
	private PanelEspecialistaPrincipal panelEspecialistaPrincipal;
	private PanelDirectorMedico panelDirectorMedico;

	/**
	 * Constructor de la clase VentanaPrincipal.
	 * 
	 * @param listener el ActionListener para manejar eventos de acción.
	 */
	public VentanaPrincipal(ActionListener listener) {
		this.listener = listener;
		this.panelLogin = new PanelLogin(listener);
		this.panelPacientePrincipal = new PanelPacientePrincipal(listener);
		this.panelEspecialistaPrincipal = new PanelEspecialistaPrincipal(listener);
		this.panelDirectorMedico = new PanelDirectorMedico(listener);
		this.panelPacienteAgendarCita = new PanelPacienteAgendarCita(listener);

		this.setSize(500, 600);
		this.setTitle("Bosque Health");
		this.setResizable(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mostrarPanelLogin();
		this.setVisible(true);
	}

	/**
	 * Muestra el panel de login.
	 */
	public void mostrarPanelLogin() {
		this.getContentPane().removeAll();
		this.add(this.panelLogin);
		this.revalidate();
		this.repaint();
	}

	/**
	 * Muestra el panel principal del paciente.
	 * 
	 * @param proximasCitasTableCitas la lista de próximas citas del paciente.
	 */
	public void mostrarPanelPacientePrincipal(List<CitaDTO> proximasCitasTableCitas) {
		this.getContentPane().removeAll();
		this.add(this.panelPacientePrincipal);
		this.panelPacientePrincipal.actualizarProximasCitasTable(proximasCitasTableCitas);
		this.revalidate();
		this.repaint();
	}
	
	/**
	 * Muestra el panel para agendar una cita.
	 * 
	 * @param citaDisponibles la lista de citas disponibles.
	 */
	public void mostrarPanelPacienteAgendarCita( List<CitaDisponibleDTO> citaDisponibles) {
		this.getContentPane().removeAll();
		this.add(this.panelPacienteAgendarCita);
		this.panelPacienteAgendarCita.actualizarCitaDisponibleTable(citaDisponibles);
		this.revalidate();
		this.repaint();
	}

	/**
	 * Muestra el panel principal del especialista.
	 */
	public void mostrarPanelEspecialistaPrincipal() {
		this.getContentPane().removeAll();
		this.add(this.panelEspecialistaPrincipal);
		this.revalidate();
		this.repaint();
	}

	/**
	 * Muestra el panel del director médico.
	 * 
	 * @param especialistas la lista de especialistas.
	 * @param turnos la lista de turnos.
	 */
	public void mostrarPanelDirectorMedico(List<PersonaDTO> especialistas, List<TurnoDTO> turnos) {
		this.getContentPane().removeAll();
		this.add(this.panelDirectorMedico);
		this.panelDirectorMedico.setEspecialitas(especialistas);
		this.panelDirectorMedico.actualizarTurnosTable(turnos);
		this.revalidate();
		this.repaint();
	}

	public PanelLogin getPanelLogin() {
		return panelLogin;
	}

	public PanelPacientePrincipal getPanelPacientePrincipal() {
		return panelPacientePrincipal;
	}

	public PanelDirectorMedico getPanelDirectorMedico() {
		return panelDirectorMedico;
	}

	public PanelPacienteAgendarCita getPanelPacienteAgendarCita() {
		return panelPacienteAgendarCita;
	}

	public PanelEspecialistaPrincipal getPanelEspecialistaPrincipal() {
		return panelEspecialistaPrincipal;
	}

	/**
	 * Muestra un mensaje de error.
	 * 
	 * @param message el mensaje de error a mostrar.
	 */
	public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

	/**
	 * Muestra un mensaje informativo.
	 * 
	 * @param message el mensaje informativo a mostrar.
	 */
	public void showMessage(String message) {
		JOptionPane.showMessageDialog(this, message, "Mensaje", JOptionPane.INFORMATION_MESSAGE);
	}
}
