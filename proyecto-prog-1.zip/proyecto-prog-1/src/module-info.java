/**
 * 
 */
/**
 * 
 */
module Proyecto {
    requires java.desktop;
	requires junit;
	requires java.mail;
	requires com.github.lgooddatepicker;
}